const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector("[data-nav]");

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("active");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("active");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });
}

const leadForm = document.getElementById("leadForm");
const formNote = document.getElementById("formNote");

if (leadForm) {
  leadForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const data = new FormData(leadForm);
    const name = data.get("name") || "";
    const email = data.get("email") || "";
    const phone = data.get("phone") || "";
    const goal = data.get("goal") || "";
    const message = data.get("message") || "No additional details provided.";

    const subject = encodeURIComponent("New Venture Digital Project Inquiry");
    const body = encodeURIComponent(
      `New project inquiry from the Venture Digital website:\n\n` +
      `Name: ${name}\n` +
      `Email: ${email}\n` +
      `Phone: ${phone}\n` +
      `Main Goal: ${goal}\n\n` +
      `Project Details:\n${message}`
    );

    window.location.href = `mailto:venturedigital2027@gmail.com?subject=${subject}&body=${body}`;

    if (formNote) {
      formNote.textContent = "Opening your email app with the project details filled in.";
    }
  });
}

const revealItems = document.querySelectorAll(
  ".service-card, .benefit-item, blockquote, .process-grid article, .results-card, .contact-panel"
);

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.14 }
);

revealItems.forEach((item) => {
  item.classList.add("reveal");
  revealObserver.observe(item);
});
