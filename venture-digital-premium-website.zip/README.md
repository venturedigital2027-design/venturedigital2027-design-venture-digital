# Venture Digital Premium Website

A finished, agency-style landing page for Venture Digital.

## Included

- `index.html`
- `style.css`
- `script.js`
- Responsive premium design
- Hero visual dashboard
- Services section
- Benefits/results section
- Social proof section
- Process section
- FAQ section
- Contact form
- Polished footer
- SEO metadata
- Schema markup

## GitHub Pages Deployment

1. Create a GitHub repository.
2. Upload all files from this folder.
3. Go to **Settings → Pages**.
4. Choose **Deploy from branch**.
5. Select `main` and `/root`.
6. Save.

## Important Form Note

The form currently uses `mailto:` so it opens the visitor's email app with the project details filled in.

For production lead capture, connect the form to:
- Formspree
- Netlify Forms
- Zapier
- Make
- Airtable
- HubSpot
- GoHighLevel
- A custom backend
